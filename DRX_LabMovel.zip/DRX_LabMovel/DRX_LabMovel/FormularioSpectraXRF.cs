﻿using ScottPlot;
using ScottPlot.Plottable;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DRX_LabMovel
{
    public partial class FormularioSpectraXRF : Form
    {

        private List<double> eixoXCalibrado;
        private List<double> eixoYCalibrado;

        public FormularioSpectraXRF()
        {
            InitializeComponent();
            eixoXCalibrado = new List<double>();
            eixoYCalibrado = new List<double>();
        }

        private void BtnAbrirArquivosXRF_Click(object sender, EventArgs e)
        {
            OpenFileDialog abrirArquivos = new OpenFileDialog()
            {
                Filter = "Text Files (*.txt)|*.txt",
                Title = "Selecione o arquivo",
                Multiselect = true,
            };

            if (abrirArquivos.ShowDialog() == DialogResult.OK)
            {
                txtDiretorioDosArquivos.Text = Path.GetDirectoryName(abrirArquivos.FileNames[0]);

                if (abrirArquivos.FileNames.Length > 1)
                    ExtracaoDeInformacaoesDosArquivos(abrirArquivos.FileNames, 1);
                else
                    ExtracaoDeInformacaoesDosArquivos(abrirArquivos.FileNames, 0);
            }
        }

        private void ExtracaoDeInformacaoesDosArquivos(string[] arquivos, int quantidadeDeArquivos)
        {

            string anguloDoArquivo = string.Empty;

            if (quantidadeDeArquivos == 0)
            {
                string arquivoRecebido = arquivos[0];

                if (!Directory.Exists(arquivos[0]))
                {
                    if (arquivoRecebido.Contains("spectro_"))
                    {
                        anguloDoArquivo = arquivoRecebido.Substring(arquivoRecebido.LastIndexOf("_") + 1);
                        anguloDoArquivo = anguloDoArquivo[..anguloDoArquivo.LastIndexOf(".")];

                        FileInfo fileInfo = new($@"{arquivoRecebido}");

                        if (fileInfo.Length == 0)
                            MessageBox.Show("Arquivo vazio ou inválido para leitura.", "Arquivo", MessageBoxButtons.OK);
                        else
                            CalibracaoDoArquivoDeEspectro(arquivoRecebido, anguloDoArquivo, 0);
                    }

                    else
                        MessageBox.Show("O arquivo precisa começar com a nomeclatura: spectro_.", "Arquivo", MessageBoxButtons.OK);
                }
            }
            else
            {
                //Logica para plotar diversos arquivos
            }
        }

        private void CalibracaoDoArquivoDeEspectro(string arquivo, string anguloDoNomeDoArquivo, int numeroDeArquivos)
        {

            double energiaFe = 6.4;
            double energiaCr = 5.41;
            double canalFe = 796;
            double canalCr = 636;

            txtEquacaoDeCalibracao.Clear();

            if (numeroDeArquivos == 0)
            {
                string[] linhasDoArquivo = File.ReadAllLines(arquivo);

                double coenficienteA = Math.Round(((energiaFe - energiaCr) / (canalFe - canalCr)), 5);
                double coenficienteB = Math.Round((energiaCr - (coenficienteA * canalCr)), 5);

                txtEquacaoDeCalibracao.Text = string.Format("y = {0}x + {1}", coenficienteA, coenficienteB);

                eixoXCalibrado.Clear();
                eixoYCalibrado.Clear();


                for (int i = 0; i < linhasDoArquivo.Length; i++)
                {
                    eixoXCalibrado.Add(((coenficienteA * i) + coenficienteB));
                    eixoYCalibrado.Add(Convert.ToDouble(linhasDoArquivo[i]));
                }

                PlotagemDoEspectro(anguloDoNomeDoArquivo, arquivo);

            }
        }

        private void PlotagemDoEspectro(string angulo, string arquivo)
        {
            scpGrafico.plt.Title(Path.GetFileName(arquivo));
            scpGrafico.plt.AddScatterLines(eixoXCalibrado.ToArray(), eixoYCalibrado.ToArray());
            scpGrafico.plt.Legend();
            scpGrafico.Refresh();
        }

        

        
    }
}
