﻿using ScottPlot;

namespace DRX_LabMovel
{
    partial class FormularioSpectraXRF
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            scpGrafico = new FormsPlot();
            pnlFundoDoGrafico = new Panel();
            pnlControles = new Panel();
            grpArquivos = new GroupBox();
            btnAbrirArquivosXRF = new Button();
            txtDiretorioDosArquivos = new TextBox();
            grpRoiSpectro = new GroupBox();
            btnAdicionar = new Button();
            lblCoordenadaXDoisDoRoi = new Label();
            lblCoordenadaXUmDoRoi = new Label();
            txtCoordenadaXUmDoRoi = new TextBox();
            txtCoordenadaXDoisDoRoi = new TextBox();
            grpCalibracaoSpectro = new GroupBox();
            lblEquacaoDeCalibracao = new Label();
            txtEquacaoDeCalibracao = new TextBox();
            grpCoordenadas = new GroupBox();
            lblCoordenadaYNoGrafico = new Label();
            lblCoordenadaXNoGrafico = new Label();
            txtCoordenadaXNoGrafico = new TextBox();
            txtCoordenadaYNoGrafico = new TextBox();
            pnlFundoDoGrafico.SuspendLayout();
            pnlControles.SuspendLayout();
            grpArquivos.SuspendLayout();
            grpRoiSpectro.SuspendLayout();
            grpCalibracaoSpectro.SuspendLayout();
            grpCoordenadas.SuspendLayout();
            SuspendLayout();
            // 
            // scpGrafico
            // 
            scpGrafico.Dock = DockStyle.Fill;
            scpGrafico.Location = new Point(0, 0);
            scpGrafico.Margin = new Padding(4, 3, 4, 3);
            scpGrafico.Name = "scpGrafico";
            scpGrafico.Size = new Size(1237, 614);
            scpGrafico.TabIndex = 0;
            // 
            // pnlFundoDoGrafico
            // 
            pnlFundoDoGrafico.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            pnlFundoDoGrafico.BackColor = SystemColors.Control;
            pnlFundoDoGrafico.Controls.Add(scpGrafico);
            pnlFundoDoGrafico.Location = new Point(12, 105);
            pnlFundoDoGrafico.Name = "pnlFundoDoGrafico";
            pnlFundoDoGrafico.Size = new Size(1237, 614);
            pnlFundoDoGrafico.TabIndex = 12;
            // 
            // pnlControles
            // 
            pnlControles.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            pnlControles.BackColor = SystemColors.Control;
            pnlControles.Controls.Add(grpArquivos);
            pnlControles.Controls.Add(grpRoiSpectro);
            pnlControles.Controls.Add(grpCalibracaoSpectro);
            pnlControles.Controls.Add(grpCoordenadas);
            pnlControles.Location = new Point(12, 12);
            pnlControles.Name = "pnlControles";
            pnlControles.Size = new Size(1237, 87);
            pnlControles.TabIndex = 13;
            // 
            // grpArquivos
            // 
            grpArquivos.Anchor = AnchorStyles.None;
            grpArquivos.Controls.Add(btnAbrirArquivosXRF);
            grpArquivos.Controls.Add(txtDiretorioDosArquivos);
            grpArquivos.Location = new Point(46, 8);
            grpArquivos.Name = "grpArquivos";
            grpArquivos.Size = new Size(385, 69);
            grpArquivos.TabIndex = 20;
            grpArquivos.TabStop = false;
            grpArquivos.Text = "Arquivo com Spectro";
            // 
            // btnAbrirArquivosXRF
            // 
            btnAbrirArquivosXRF.Location = new Point(303, 25);
            btnAbrirArquivosXRF.Name = "btnAbrirArquivosXRF";
            btnAbrirArquivosXRF.Size = new Size(75, 23);
            btnAbrirArquivosXRF.TabIndex = 19;
            btnAbrirArquivosXRF.Text = "Abrir";
            btnAbrirArquivosXRF.UseVisualStyleBackColor = true;
            btnAbrirArquivosXRF.Click += BtnAbrirArquivosXRF_Click;
            // 
            // txtDiretorioDosArquivos
            // 
            txtDiretorioDosArquivos.Location = new Point(6, 25);
            txtDiretorioDosArquivos.Name = "txtDiretorioDosArquivos";
            txtDiretorioDosArquivos.Size = new Size(291, 23);
            txtDiretorioDosArquivos.TabIndex = 17;
            // 
            // grpRoiSpectro
            // 
            grpRoiSpectro.Anchor = AnchorStyles.None;
            grpRoiSpectro.Controls.Add(btnAdicionar);
            grpRoiSpectro.Controls.Add(lblCoordenadaXDoisDoRoi);
            grpRoiSpectro.Controls.Add(lblCoordenadaXUmDoRoi);
            grpRoiSpectro.Controls.Add(txtCoordenadaXUmDoRoi);
            grpRoiSpectro.Controls.Add(txtCoordenadaXDoisDoRoi);
            grpRoiSpectro.Location = new Point(437, 8);
            grpRoiSpectro.Name = "grpRoiSpectro";
            grpRoiSpectro.Size = new Size(246, 69);
            grpRoiSpectro.TabIndex = 16;
            grpRoiSpectro.TabStop = false;
            grpRoiSpectro.Text = "Roi do Spectro";
            // 
            // btnAdicionar
            // 
            btnAdicionar.Location = new Point(161, 25);
            btnAdicionar.Name = "btnAdicionar";
            btnAdicionar.Size = new Size(75, 23);
            btnAdicionar.TabIndex = 19;
            btnAdicionar.Text = "Adicionar";
            btnAdicionar.UseVisualStyleBackColor = true;
            // 
            // lblCoordenadaXDoisDoRoi
            // 
            lblCoordenadaXDoisDoRoi.AutoSize = true;
            lblCoordenadaXDoisDoRoi.Location = new Point(83, 28);
            lblCoordenadaXDoisDoRoi.Name = "lblCoordenadaXDoisDoRoi";
            lblCoordenadaXDoisDoRoi.Size = new Size(23, 15);
            lblCoordenadaXDoisDoRoi.TabIndex = 18;
            lblCoordenadaXDoisDoRoi.Text = "X'':";
            // 
            // lblCoordenadaXUmDoRoi
            // 
            lblCoordenadaXUmDoRoi.AutoSize = true;
            lblCoordenadaXUmDoRoi.Location = new Point(4, 29);
            lblCoordenadaXUmDoRoi.Name = "lblCoordenadaXUmDoRoi";
            lblCoordenadaXUmDoRoi.Size = new Size(20, 15);
            lblCoordenadaXUmDoRoi.TabIndex = 15;
            lblCoordenadaXUmDoRoi.Text = "X':";
            // 
            // txtCoordenadaXUmDoRoi
            // 
            txtCoordenadaXUmDoRoi.Location = new Point(24, 25);
            txtCoordenadaXUmDoRoi.Name = "txtCoordenadaXUmDoRoi";
            txtCoordenadaXUmDoRoi.Size = new Size(34, 23);
            txtCoordenadaXUmDoRoi.TabIndex = 17;
            // 
            // txtCoordenadaXDoisDoRoi
            // 
            txtCoordenadaXDoisDoRoi.Location = new Point(106, 25);
            txtCoordenadaXDoisDoRoi.Name = "txtCoordenadaXDoisDoRoi";
            txtCoordenadaXDoisDoRoi.Size = new Size(34, 23);
            txtCoordenadaXDoisDoRoi.TabIndex = 16;
            // 
            // grpCalibracaoSpectro
            // 
            grpCalibracaoSpectro.Anchor = AnchorStyles.None;
            grpCalibracaoSpectro.Controls.Add(lblEquacaoDeCalibracao);
            grpCalibracaoSpectro.Controls.Add(txtEquacaoDeCalibracao);
            grpCalibracaoSpectro.Location = new Point(701, 8);
            grpCalibracaoSpectro.Name = "grpCalibracaoSpectro";
            grpCalibracaoSpectro.Size = new Size(303, 69);
            grpCalibracaoSpectro.TabIndex = 15;
            grpCalibracaoSpectro.TabStop = false;
            grpCalibracaoSpectro.Text = "Calibração do spectro";
            // 
            // lblEquacaoDeCalibracao
            // 
            lblEquacaoDeCalibracao.AutoSize = true;
            lblEquacaoDeCalibracao.Location = new Point(8, 28);
            lblEquacaoDeCalibracao.Name = "lblEquacaoDeCalibracao";
            lblEquacaoDeCalibracao.Size = new Size(55, 15);
            lblEquacaoDeCalibracao.TabIndex = 12;
            lblEquacaoDeCalibracao.Text = "Equação:";
            // 
            // txtEquacaoDeCalibracao
            // 
            txtEquacaoDeCalibracao.Location = new Point(67, 24);
            txtEquacaoDeCalibracao.Name = "txtEquacaoDeCalibracao";
            txtEquacaoDeCalibracao.Size = new Size(229, 23);
            txtEquacaoDeCalibracao.TabIndex = 13;
            // 
            // grpCoordenadas
            // 
            grpCoordenadas.Anchor = AnchorStyles.None;
            grpCoordenadas.Controls.Add(lblCoordenadaYNoGrafico);
            grpCoordenadas.Controls.Add(lblCoordenadaXNoGrafico);
            grpCoordenadas.Controls.Add(txtCoordenadaXNoGrafico);
            grpCoordenadas.Controls.Add(txtCoordenadaYNoGrafico);
            grpCoordenadas.Location = new Point(1022, 10);
            grpCoordenadas.Name = "grpCoordenadas";
            grpCoordenadas.Size = new Size(164, 67);
            grpCoordenadas.TabIndex = 11;
            grpCoordenadas.TabStop = false;
            grpCoordenadas.Text = "Coordenadas no gráfico";
            // 
            // lblCoordenadaYNoGrafico
            // 
            lblCoordenadaYNoGrafico.AutoSize = true;
            lblCoordenadaYNoGrafico.Location = new Point(94, 27);
            lblCoordenadaYNoGrafico.Name = "lblCoordenadaYNoGrafico";
            lblCoordenadaYNoGrafico.Size = new Size(17, 15);
            lblCoordenadaYNoGrafico.TabIndex = 14;
            lblCoordenadaYNoGrafico.Text = "Y:";
            // 
            // lblCoordenadaXNoGrafico
            // 
            lblCoordenadaXNoGrafico.AutoSize = true;
            lblCoordenadaXNoGrafico.Location = new Point(15, 28);
            lblCoordenadaXNoGrafico.Name = "lblCoordenadaXNoGrafico";
            lblCoordenadaXNoGrafico.Size = new Size(17, 15);
            lblCoordenadaXNoGrafico.TabIndex = 12;
            lblCoordenadaXNoGrafico.Text = "X:";
            // 
            // txtCoordenadaXNoGrafico
            // 
            txtCoordenadaXNoGrafico.Location = new Point(35, 24);
            txtCoordenadaXNoGrafico.Name = "txtCoordenadaXNoGrafico";
            txtCoordenadaXNoGrafico.Size = new Size(34, 23);
            txtCoordenadaXNoGrafico.TabIndex = 13;
            // 
            // txtCoordenadaYNoGrafico
            // 
            txtCoordenadaYNoGrafico.Location = new Point(115, 23);
            txtCoordenadaYNoGrafico.Name = "txtCoordenadaYNoGrafico";
            txtCoordenadaYNoGrafico.Size = new Size(34, 23);
            txtCoordenadaYNoGrafico.TabIndex = 12;
            // 
            // FormularioSpectraXRF
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1261, 723);
            Controls.Add(pnlControles);
            Controls.Add(pnlFundoDoGrafico);
            Name = "FormularioSpectraXRF";
            Text = "Spectra  X-ray Fluorescence";
            pnlFundoDoGrafico.ResumeLayout(false);
            pnlControles.ResumeLayout(false);
            grpArquivos.ResumeLayout(false);
            grpArquivos.PerformLayout();
            grpRoiSpectro.ResumeLayout(false);
            grpRoiSpectro.PerformLayout();
            grpCalibracaoSpectro.ResumeLayout(false);
            grpCalibracaoSpectro.PerformLayout();
            grpCoordenadas.ResumeLayout(false);
            grpCoordenadas.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Label lblDiretorioEscolhido;
        private FormsPlot scpGrafico;
        private TextBox txtDiretorioEscolhido;
        private Panel pnlFundoDoGrafico;
        private Panel pnlControles;
        private GroupBox grpRoiSpectro;
        private Button btnAdicionar;
        private Label lblCoordenadaXDoisDoRoi;
        private Label lblCoordenadaXUmDoRoi;
        private TextBox txtCoordenadaXUmDoRoi;
        private TextBox txtCoordenadaXDoisDoRoi;
        private GroupBox grpCalibracaoSpectro;
        private Label lblEquacaoDeCalibracao;
        private TextBox txtEquacaoDeCalibracao;
        private GroupBox grpCoordenadas;
        private Label lblCoordenadaYNoGrafico;
        private Label lblCoordenadaXNoGrafico;
        private TextBox txtCoordenadaXNoGrafico;
        private TextBox txtCoordenadaYNoGrafico;
        private GroupBox grpArquivos;
        private Button btnAbrirArquivosXRF;
        private TextBox txtDiretorioDosArquivos;
    }
}