﻿using System.Windows.Forms;

namespace DRX_LabMovel
{
    partial class FormularioDRX
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormularioDRX));
            msMenuPrincipal = new MenuStrip();
            arquivoToolStripMenuItem = new ToolStripMenuItem();
            criarProjetoToolStripMenuItem = new ToolStripMenuItem();
            tsddbFerramentas = new ToolStripMenuItem();
            tsmiMCP = new ToolStripMenuItem();
            tratamentoDeSpectroDeXRFToolStripMenuItem = new ToolStripMenuItem();
            tsmiDetector = new ToolStripMenuItem();
            tsmiDesconectarDispositivos = new ToolStripMenuItem();
            homeToolStripMenuItem = new ToolStripMenuItem();
            definirToolStripMenuItem = new ToolStripMenuItem();
            moverseToolStripMenuItem = new ToolStripMenuItem();
            pnlGraficoPrincipal = new Panel();
            tipLegendas = new ToolTip(components);
            grpAquisicao = new GroupBox();
            btnIniciar = new Button();
            lblNumeroDeCanais = new Label();
            cmbNumeroDeCanais = new ComboBox();
            txtTempo = new TextBox();
            lblTempo = new Label();
            lblPasso = new Label();
            lblAnguloFinal = new Label();
            lblAnguloInicial = new Label();
            txtPasso = new TextBox();
            txtAnguloFinal = new TextBox();
            txtAnguloInicial = new TextBox();
            pnlControles = new Panel();
            grpAjustesMovimentacao = new GroupBox();
            btnDetectorTuboNegativo = new Button();
            btnDetectorTuboPositivo = new Button();
            lblMovimentacoTuboRaiosX_1 = new Label();
            lblMovimentacoTuboRaiosX = new Label();
            btnDetectorNegativo = new Button();
            btnDetectorPositivo = new Button();
            lblMovimentacaoDoTuboDeRaiosX = new Label();
            btnTuboNegativo = new Button();
            lblMovimentacaoDoDetectorDeRaiosX = new Label();
            btnTuboPositivo = new Button();
            picLogo = new PictureBox();
            msMenuPrincipal.SuspendLayout();
            grpAquisicao.SuspendLayout();
            pnlControles.SuspendLayout();
            grpAjustesMovimentacao.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)picLogo).BeginInit();
            SuspendLayout();
            // 
            // msMenuPrincipal
            // 
            msMenuPrincipal.ImageScalingSize = new Size(20, 20);
            msMenuPrincipal.Items.AddRange(new ToolStripItem[] { arquivoToolStripMenuItem, tsddbFerramentas, homeToolStripMenuItem });
            msMenuPrincipal.Location = new Point(0, 0);
            msMenuPrincipal.MinimumSize = new Size(1267, 32);
            msMenuPrincipal.Name = "msMenuPrincipal";
            msMenuPrincipal.Padding = new Padding(7, 3, 0, 3);
            msMenuPrincipal.Size = new Size(1467, 32);
            msMenuPrincipal.TabIndex = 0;
            // 
            // arquivoToolStripMenuItem
            // 
            arquivoToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { criarProjetoToolStripMenuItem });
            arquivoToolStripMenuItem.Name = "arquivoToolStripMenuItem";
            arquivoToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.Shift | Keys.N;
            arquivoToolStripMenuItem.Size = new Size(75, 26);
            arquivoToolStripMenuItem.Text = "Arquivo";
            // 
            // criarProjetoToolStripMenuItem
            // 
            criarProjetoToolStripMenuItem.Name = "criarProjetoToolStripMenuItem";
            criarProjetoToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.Shift | Keys.N;
            criarProjetoToolStripMenuItem.Size = new Size(268, 26);
            criarProjetoToolStripMenuItem.Text = "Criar Projeto";
            criarProjetoToolStripMenuItem.Click += criarProjetoToolStripMenuItem_Click;
            // 
            // tsddbFerramentas
            // 
            tsddbFerramentas.DropDownItems.AddRange(new ToolStripItem[] { tsmiMCP, tratamentoDeSpectroDeXRFToolStripMenuItem, tsmiDetector, tsmiDesconectarDispositivos });
            tsddbFerramentas.Name = "tsddbFerramentas";
            tsddbFerramentas.Size = new Size(104, 26);
            tsddbFerramentas.Text = "Ferramentas";
            tsddbFerramentas.Click += tsddbFerramentas_Click;
            // 
            // tsmiMCP
            // 
            tsmiMCP.Name = "tsmiMCP";
            tsmiMCP.Size = new Size(356, 26);
            tsmiMCP.Text = "Módulo de Controle de Posicionamento";
            tsmiMCP.DropDownOpening += tsmiMCP_DropDownOpening;
            // 
            // tratamentoDeSpectroDeXRFToolStripMenuItem
            // 
            tratamentoDeSpectroDeXRFToolStripMenuItem.Name = "tratamentoDeSpectroDeXRFToolStripMenuItem";
            tratamentoDeSpectroDeXRFToolStripMenuItem.Size = new Size(356, 26);
            tratamentoDeSpectroDeXRFToolStripMenuItem.Text = "Tratamento de spectro de XRF";
            tratamentoDeSpectroDeXRFToolStripMenuItem.Click += tratamentoDeSpectroDeXRFToolStripMenuItem_Click;
            // 
            // tsmiDetector
            // 
            tsmiDetector.Name = "tsmiDetector";
            tsmiDetector.Size = new Size(356, 26);
            tsmiDetector.Text = "Detector de Raios X";
            // 
            // tsmiDesconectarDispositivos
            // 
            tsmiDesconectarDispositivos.Name = "tsmiDesconectarDispositivos";
            tsmiDesconectarDispositivos.ShortcutKeys = Keys.Control | Keys.Shift | Keys.D;
            tsmiDesconectarDispositivos.Size = new Size(356, 26);
            tsmiDesconectarDispositivos.Text = "Desconectar dispositivos";
            tsmiDesconectarDispositivos.Click += tsmiDesconectarDispositivos_Click;
            // 
            // homeToolStripMenuItem
            // 
            homeToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { definirToolStripMenuItem, moverseToolStripMenuItem });
            homeToolStripMenuItem.Name = "homeToolStripMenuItem";
            homeToolStripMenuItem.Size = new Size(64, 26);
            homeToolStripMenuItem.Text = "Home";
            // 
            // definirToolStripMenuItem
            // 
            definirToolStripMenuItem.Name = "definirToolStripMenuItem";
            definirToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.D;
            definirToolStripMenuItem.Size = new Size(209, 26);
            definirToolStripMenuItem.Text = "Definir";
            definirToolStripMenuItem.Click += definirToolStripMenuItem_Click;
            // 
            // moverseToolStripMenuItem
            // 
            moverseToolStripMenuItem.Name = "moverseToolStripMenuItem";
            moverseToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.M;
            moverseToolStripMenuItem.Size = new Size(209, 26);
            moverseToolStripMenuItem.Text = "Mover-se";
            moverseToolStripMenuItem.Click += moverseToolStripMenuItem_Click;
            // 
            // pnlGraficoPrincipal
            // 
            pnlGraficoPrincipal.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            pnlGraficoPrincipal.BackColor = SystemColors.WindowText;
            pnlGraficoPrincipal.Location = new Point(315, 36);
            pnlGraficoPrincipal.Margin = new Padding(3, 4, 3, 4);
            pnlGraficoPrincipal.Name = "pnlGraficoPrincipal";
            pnlGraficoPrincipal.Size = new Size(1138, 868);
            pnlGraficoPrincipal.TabIndex = 3;
            // 
            // tipLegendas
            // 
            tipLegendas.IsBalloon = true;
            // 
            // grpAquisicao
            // 
            grpAquisicao.Anchor = AnchorStyles.Left;
            grpAquisicao.Controls.Add(btnIniciar);
            grpAquisicao.Controls.Add(lblNumeroDeCanais);
            grpAquisicao.Controls.Add(cmbNumeroDeCanais);
            grpAquisicao.Controls.Add(txtTempo);
            grpAquisicao.Controls.Add(lblTempo);
            grpAquisicao.Controls.Add(lblPasso);
            grpAquisicao.Controls.Add(lblAnguloFinal);
            grpAquisicao.Controls.Add(lblAnguloInicial);
            grpAquisicao.Controls.Add(txtPasso);
            grpAquisicao.Controls.Add(txtAnguloFinal);
            grpAquisicao.Controls.Add(txtAnguloInicial);
            grpAquisicao.Location = new Point(2, 104);
            grpAquisicao.Margin = new Padding(3, 4, 3, 4);
            grpAquisicao.Name = "grpAquisicao";
            grpAquisicao.Padding = new Padding(3, 4, 3, 4);
            grpAquisicao.Size = new Size(288, 248);
            grpAquisicao.TabIndex = 6;
            grpAquisicao.TabStop = false;
            grpAquisicao.Text = "Aquisição";
            // 
            // btnIniciar
            // 
            btnIniciar.Enabled = false;
            btnIniciar.Location = new Point(16, 191);
            btnIniciar.Margin = new Padding(3, 4, 3, 4);
            btnIniciar.Name = "btnIniciar";
            btnIniciar.Size = new Size(262, 31);
            btnIniciar.TabIndex = 16;
            btnIniciar.Text = "Iniciar";
            btnIniciar.UseVisualStyleBackColor = true;
            btnIniciar.Click += BtnIniciar_Click;
            // 
            // lblNumeroDeCanais
            // 
            lblNumeroDeCanais.AutoSize = true;
            lblNumeroDeCanais.Location = new Point(175, 115);
            lblNumeroDeCanais.Name = "lblNumeroDeCanais";
            lblNumeroDeCanais.Size = new Size(89, 20);
            lblNumeroDeCanais.TabIndex = 15;
            lblNumeroDeCanais.Text = "N. de canais";
            // 
            // cmbNumeroDeCanais
            // 
            cmbNumeroDeCanais.FormattingEnabled = true;
            cmbNumeroDeCanais.Items.AddRange(new object[] { "4096" });
            cmbNumeroDeCanais.Location = new Point(152, 140);
            cmbNumeroDeCanais.Margin = new Padding(3, 4, 3, 4);
            cmbNumeroDeCanais.Name = "cmbNumeroDeCanais";
            cmbNumeroDeCanais.Size = new Size(125, 28);
            cmbNumeroDeCanais.TabIndex = 14;
            cmbNumeroDeCanais.KeyDown += cmbNumeroDeCanais_KeyDown;
            // 
            // txtTempo
            // 
            txtTempo.Location = new Point(16, 141);
            txtTempo.Margin = new Padding(3, 4, 3, 4);
            txtTempo.Name = "txtTempo";
            txtTempo.Size = new Size(119, 27);
            txtTempo.TabIndex = 13;
            txtTempo.KeyDown += txtTempo_KeyDown;
            // 
            // lblTempo
            // 
            lblTempo.AutoSize = true;
            lblTempo.Location = new Point(16, 115);
            lblTempo.Name = "lblTempo";
            lblTempo.Size = new Size(128, 20);
            lblTempo.TabIndex = 12;
            lblTempo.Text = "T. de aquisição (s)";
            // 
            // lblPasso
            // 
            lblPasso.AutoSize = true;
            lblPasso.Location = new Point(183, 57);
            lblPasso.Name = "lblPasso";
            lblPasso.Size = new Size(24, 20);
            lblPasso.TabIndex = 11;
            lblPasso.Text = "P :";
            // 
            // lblAnguloFinal
            // 
            lblAnguloFinal.AutoSize = true;
            lblAnguloFinal.Location = new Point(98, 57);
            lblAnguloFinal.Name = "lblAnguloFinal";
            lblAnguloFinal.Size = new Size(31, 20);
            lblAnguloFinal.TabIndex = 10;
            lblAnguloFinal.Text = "θ'' :";
            // 
            // lblAnguloInicial
            // 
            lblAnguloInicial.AutoSize = true;
            lblAnguloInicial.Location = new Point(18, 57);
            lblAnguloInicial.Name = "lblAnguloInicial";
            lblAnguloInicial.Size = new Size(28, 20);
            lblAnguloInicial.TabIndex = 9;
            lblAnguloInicial.Tag = "a";
            lblAnguloInicial.Text = "θ' :";
            // 
            // txtPasso
            // 
            txtPasso.Location = new Point(210, 52);
            txtPasso.Margin = new Padding(3, 4, 3, 4);
            txtPasso.Name = "txtPasso";
            txtPasso.Size = new Size(44, 27);
            txtPasso.TabIndex = 8;
            txtPasso.KeyDown += txtPasso_KeyDown;
            // 
            // txtAnguloFinal
            // 
            txtAnguloFinal.Location = new Point(128, 52);
            txtAnguloFinal.Margin = new Padding(3, 4, 3, 4);
            txtAnguloFinal.Name = "txtAnguloFinal";
            txtAnguloFinal.Size = new Size(44, 27);
            txtAnguloFinal.TabIndex = 7;
            txtAnguloFinal.KeyDown += txtAnguloFinal_KeyDown;
            // 
            // txtAnguloInicial
            // 
            txtAnguloInicial.Location = new Point(47, 52);
            txtAnguloInicial.Margin = new Padding(3, 4, 3, 4);
            txtAnguloInicial.Name = "txtAnguloInicial";
            txtAnguloInicial.Size = new Size(43, 27);
            txtAnguloInicial.TabIndex = 6;
            txtAnguloInicial.KeyDown += txtAnguloInicial_KeyDown;
            // 
            // pnlControles
            // 
            pnlControles.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            pnlControles.BackColor = SystemColors.Control;
            pnlControles.Controls.Add(grpAjustesMovimentacao);
            pnlControles.Controls.Add(picLogo);
            pnlControles.Controls.Add(grpAquisicao);
            pnlControles.Location = new Point(14, 36);
            pnlControles.Margin = new Padding(3, 4, 3, 4);
            pnlControles.Name = "pnlControles";
            pnlControles.Size = new Size(295, 868);
            pnlControles.TabIndex = 4;
            // 
            // grpAjustesMovimentacao
            // 
            grpAjustesMovimentacao.Anchor = AnchorStyles.Left;
            grpAjustesMovimentacao.Controls.Add(btnDetectorTuboNegativo);
            grpAjustesMovimentacao.Controls.Add(btnDetectorTuboPositivo);
            grpAjustesMovimentacao.Controls.Add(lblMovimentacoTuboRaiosX_1);
            grpAjustesMovimentacao.Controls.Add(lblMovimentacoTuboRaiosX);
            grpAjustesMovimentacao.Controls.Add(btnDetectorNegativo);
            grpAjustesMovimentacao.Controls.Add(btnDetectorPositivo);
            grpAjustesMovimentacao.Controls.Add(lblMovimentacaoDoTuboDeRaiosX);
            grpAjustesMovimentacao.Controls.Add(btnTuboNegativo);
            grpAjustesMovimentacao.Controls.Add(lblMovimentacaoDoDetectorDeRaiosX);
            grpAjustesMovimentacao.Controls.Add(btnTuboPositivo);
            grpAjustesMovimentacao.Location = new Point(2, 387);
            grpAjustesMovimentacao.Margin = new Padding(3, 4, 3, 4);
            grpAjustesMovimentacao.Name = "grpAjustesMovimentacao";
            grpAjustesMovimentacao.Padding = new Padding(3, 4, 3, 4);
            grpAjustesMovimentacao.Size = new Size(288, 279);
            grpAjustesMovimentacao.TabIndex = 18;
            grpAjustesMovimentacao.TabStop = false;
            grpAjustesMovimentacao.Text = "Ajuste da Movimentação";
            // 
            // btnDetectorTuboNegativo
            // 
            btnDetectorTuboNegativo.Location = new Point(154, 225);
            btnDetectorTuboNegativo.Margin = new Padding(3, 4, 3, 4);
            btnDetectorTuboNegativo.Name = "btnDetectorTuboNegativo";
            btnDetectorTuboNegativo.Size = new Size(86, 31);
            btnDetectorTuboNegativo.TabIndex = 26;
            btnDetectorTuboNegativo.Text = "- 0.12";
            btnDetectorTuboNegativo.UseVisualStyleBackColor = true;
            // 
            // btnDetectorTuboPositivo
            // 
            btnDetectorTuboPositivo.Location = new Point(43, 225);
            btnDetectorTuboPositivo.Margin = new Padding(3, 4, 3, 4);
            btnDetectorTuboPositivo.Name = "btnDetectorTuboPositivo";
            btnDetectorTuboPositivo.Size = new Size(86, 31);
            btnDetectorTuboPositivo.TabIndex = 25;
            btnDetectorTuboPositivo.Text = "+ 0.12";
            btnDetectorTuboPositivo.UseVisualStyleBackColor = true;
            // 
            // lblMovimentacoTuboRaiosX_1
            // 
            lblMovimentacoTuboRaiosX_1.AutoSize = true;
            lblMovimentacoTuboRaiosX_1.Location = new Point(59, 201);
            lblMovimentacoTuboRaiosX_1.Name = "lblMovimentacoTuboRaiosX_1";
            lblMovimentacoTuboRaiosX_1.Size = new Size(179, 20);
            lblMovimentacoTuboRaiosX_1.TabIndex = 24;
            lblMovimentacoTuboRaiosX_1.Text = " e do Detector de Raios X";
            // 
            // lblMovimentacoTuboRaiosX
            // 
            lblMovimentacoTuboRaiosX.AutoSize = true;
            lblMovimentacoTuboRaiosX.Location = new Point(30, 176);
            lblMovimentacoTuboRaiosX.Name = "lblMovimentacoTuboRaiosX";
            lblMovimentacoTuboRaiosX.Size = new Size(242, 20);
            lblMovimentacoTuboRaiosX.TabIndex = 23;
            lblMovimentacoTuboRaiosX.Text = "Movimentação do Tubo de Raios X";
            // 
            // btnDetectorNegativo
            // 
            btnDetectorNegativo.Location = new Point(154, 73);
            btnDetectorNegativo.Margin = new Padding(3, 4, 3, 4);
            btnDetectorNegativo.Name = "btnDetectorNegativo";
            btnDetectorNegativo.Size = new Size(86, 31);
            btnDetectorNegativo.TabIndex = 22;
            btnDetectorNegativo.Text = "- 0.12";
            btnDetectorNegativo.UseVisualStyleBackColor = true;
            // 
            // btnDetectorPositivo
            // 
            btnDetectorPositivo.Location = new Point(49, 73);
            btnDetectorPositivo.Margin = new Padding(3, 4, 3, 4);
            btnDetectorPositivo.Name = "btnDetectorPositivo";
            btnDetectorPositivo.Size = new Size(86, 31);
            btnDetectorPositivo.TabIndex = 21;
            btnDetectorPositivo.Text = "+ 0.12";
            btnDetectorPositivo.UseVisualStyleBackColor = true;
            // 
            // lblMovimentacaoDoTuboDeRaiosX
            // 
            lblMovimentacaoDoTuboDeRaiosX.AutoSize = true;
            lblMovimentacaoDoTuboDeRaiosX.Location = new Point(30, 112);
            lblMovimentacaoDoTuboDeRaiosX.Name = "lblMovimentacaoDoTuboDeRaiosX";
            lblMovimentacaoDoTuboDeRaiosX.Size = new Size(242, 20);
            lblMovimentacaoDoTuboDeRaiosX.TabIndex = 20;
            lblMovimentacaoDoTuboDeRaiosX.Text = "Movimentação do Tubo de Raios X";
            // 
            // btnTuboNegativo
            // 
            btnTuboNegativo.Location = new Point(154, 136);
            btnTuboNegativo.Margin = new Padding(3, 4, 3, 4);
            btnTuboNegativo.Name = "btnTuboNegativo";
            btnTuboNegativo.Size = new Size(86, 31);
            btnTuboNegativo.TabIndex = 19;
            btnTuboNegativo.Text = "- 0.12";
            btnTuboNegativo.UseVisualStyleBackColor = true;
            // 
            // lblMovimentacaoDoDetectorDeRaiosX
            // 
            lblMovimentacaoDoDetectorDeRaiosX.AutoSize = true;
            lblMovimentacaoDoDetectorDeRaiosX.Location = new Point(19, 49);
            lblMovimentacaoDoDetectorDeRaiosX.Name = "lblMovimentacaoDoDetectorDeRaiosX";
            lblMovimentacaoDoDetectorDeRaiosX.Size = new Size(266, 20);
            lblMovimentacaoDoDetectorDeRaiosX.TabIndex = 18;
            lblMovimentacaoDoDetectorDeRaiosX.Text = "Movimentação do Detector de Raios X";
            // 
            // btnTuboPositivo
            // 
            btnTuboPositivo.Location = new Point(49, 136);
            btnTuboPositivo.Margin = new Padding(3, 4, 3, 4);
            btnTuboPositivo.Name = "btnTuboPositivo";
            btnTuboPositivo.Size = new Size(86, 31);
            btnTuboPositivo.TabIndex = 17;
            btnTuboPositivo.Text = "+ 0.12";
            btnTuboPositivo.UseVisualStyleBackColor = true;
            // 
            // picLogo
            // 
            picLogo.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            picLogo.BackgroundImageLayout = ImageLayout.Zoom;
            picLogo.Image = (Image)resources.GetObject("picLogo.Image");
            picLogo.Location = new Point(11, 791);
            picLogo.Margin = new Padding(3, 4, 3, 4);
            picLogo.Name = "picLogo";
            picLogo.Size = new Size(271, 73);
            picLogo.SizeMode = PictureBoxSizeMode.StretchImage;
            picLogo.TabIndex = 25;
            picLogo.TabStop = false;
            // 
            // FormularioDRX
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1467, 933);
            Controls.Add(pnlControles);
            Controls.Add(pnlGraficoPrincipal);
            Controls.Add(msMenuPrincipal);
            MainMenuStrip = msMenuPrincipal;
            Margin = new Padding(3, 4, 3, 4);
            MinimumSize = new Size(1455, 932);
            Name = "FormularioDRX";
            SizeGripStyle = SizeGripStyle.Show;
            Text = "FormularioDRX";
            FormClosing += FormularioDRX_FormClosing;
            Load += FormularioDRX_Load;
            msMenuPrincipal.ResumeLayout(false);
            msMenuPrincipal.PerformLayout();
            grpAquisicao.ResumeLayout(false);
            grpAquisicao.PerformLayout();
            pnlControles.ResumeLayout(false);
            grpAjustesMovimentacao.ResumeLayout(false);
            grpAjustesMovimentacao.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)picLogo).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip msMenuPrincipal;
        private ToolStripMenuItem tsddbFerramentas;
        private ToolStripMenuItem tsmiMCP;
        private ToolStripMenuItem tsmiDetector;
        private ToolStripMenuItem tsmiDesconectarDispositivos;
        private Panel pnlGraficoPrincipal;
        private ToolTip tipLegendas;
        private GroupBox grpAquisicao;
        private Label lblPasso;
        private Label lblAnguloFinal;
        private Label lblAnguloInicial;
        private TextBox txtPasso;
        private TextBox txtAnguloFinal;
        private TextBox txtAnguloInicial;
        private Panel pnlControles;
        private Label lblTempo;
        private ComboBox cmbNumeroDeCanais;
        private TextBox txtTempo;
        private Button btnIniciar;
        private Label lblNumeroDeCanais;
        private PictureBox picLogo;
        private GroupBox grpAjustesMovimentacao;
        private Button btnTuboPositivo;
        private Label lblMovimentacaoDoTuboDeRaiosX;
        private Button btnTuboNegativo;
        private Label lblMovimentacaoDoDetectorDeRaiosX;
        private Button btnDetectorPositivo;
        private Button btnDetectorNegativo;
        private ToolStripMenuItem arquivoToolStripMenuItem;
        private ToolStripMenuItem criarProjetoToolStripMenuItem;
        private Button btnDefinirHome;
        private ToolStripMenuItem homeToolStripMenuItem;
        private ToolStripMenuItem definirToolStripMenuItem;
        private ToolStripMenuItem moverseToolStripMenuItem;
        private ToolStripMenuItem tratamentoDeSpectroDeXRFToolStripMenuItem;
        private Label lblMovimentacoTuboRaiosX;
        private Button btnDetectorTuboNegativo;
        private Button btnDetectorTuboPositivo;
        private Label lblMovimentacoTuboRaiosX_1;


    }
}