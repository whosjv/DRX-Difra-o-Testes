﻿using DRX_ArtAnalysis;
using System.Diagnostics;

namespace DRX_LabMovel.Classes
{
    public  class Detector
    {
        private int status { get; set; }
        private uint ValidaConexao { get; set; }

        PrioridadesDoSensor _niveisDePrioridadeDoSensor;
        ModoDoArquivoDeLog _modoDoArquivoDeLog;
        StatusDaAPI _statusDaAPI;
        ConstantesHandel _constantesHandel;

        public Detector()
        {
            _modoDoArquivoDeLog = new ModoDoArquivoDeLog();
            _constantesHandel = new ConstantesHandel();
            _niveisDePrioridadeDoSensor = new PrioridadesDoSensor();
            _statusDaAPI = new StatusDaAPI();

        }

        private static void LogDeErro(string linha, string descricao)
        {
            using (StreamWriter escreverArquivo = new StreamWriter(@"Log_Software.txt"))
                escreverArquivo.WriteLine($"Linha:{linha}, Messagem:{descricao}\n");
        }

        public bool InicializaDetector()
        {
            try
            {
                StackFrame stack = new StackFrame();

                Handel.xiaSetLogLevel(_modoDoArquivoDeLog.MD_DEBUG);
                Handel.xiaSetLogOutput("handel.log");
                
                status = Handel.xiaInit($"{Environment.CurrentDirectory}\\default.ini");

                if (status == _statusDaAPI.XIA_SUCCESS)
                {
                    LogDeErro(stack.GetFileLineNumber().ToString(), "Configuração carregada.");
                    ValidaConexao += 1;
                }

                Handel.xiaSetIOPriority(_niveisDePrioridadeDoSensor.MD_IO_PRI_HIGH);
                status = Handel.xiaStartSystem(); 

                if (status == _statusDaAPI.XIA_SUCCESS)
                {
                    LogDeErro(stack.GetFileLineNumber().ToString(), "Sistema inicializado.");
                    ValidaConexao += 1;
                }

                if (ValidaConexao == 2)
                {
                    ValidaConexao = 0;
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch (Exception ex)
            {
                LogDeErro(ex.StackTrace.Substring(ex.StackTrace.IndexOf("line")), ex.Message);
                return false;
            }
        }

        public void InicializaParametros()
        {
            if (status == _statusDaAPI.XIA_SUCCESS)
            {
                char aplicacaoDoParametros = Convert.ToChar(_constantesHandel.AV_MEM_PARSET | _constantesHandel.AV_MEM_GENSET);

                var valor = 2.0;
                status = Handel.xiaSetAcquisitionValues(0, "mca_bin_width", ref valor);

                valor = 4096.0;
                status = Handel.xiaSetAcquisitionValues(0, "number_mca_channels", ref valor);
                valor = 20.0;
                status = Handel.xiaSetAcquisitionValues(0, "trigger_threshold", ref valor);

                valor = 6.150;
                status = Handel.xiaSetAcquisitionValues(0, "gain", ref valor);

                valor = 1.0;
                status = Handel.xiaSetAcquisitionValues(0, "polarity", ref valor);

                valor = 100.0;
                status = Handel.xiaSetAcquisitionValues(0, "preamp_value", ref valor);

                status = Handel.xiaBoardOperation(0, "apply", ref aplicacaoDoParametros);
            }
        }

        public void CapturarEspectro(double i, double auxPosicaoDeInicio)
        {
            ushort mcaSize = 0;

            status = Handel.xiaStartRun(0, 0);
            Thread.Sleep((int)(FormularioDRX.tempoDeExecucao * 1000));
            status = Handel.xiaStopRun(0);

            status = Handel.xiaGetRunData(0, "mca_length", ref mcaSize);
            uint[] valor = new uint[mcaSize];
            status = Handel.xiaGetRunData(0, "mca", valor);


            using (StreamWriter writer = new StreamWriter($"{FormularioDRX.caminhoDoArquivoDoProjeto}//spectro_{Math.Round((((i * 0.5) / 0.120) + auxPosicaoDeInicio), 5)}.txt"))
            {
                foreach (uint value in valor)
                    writer.WriteLine(value);
            }
        }
    }
}
