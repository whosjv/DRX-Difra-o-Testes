﻿
namespace DRX_ArtAnalysis
{
    public class ModoDoArquivoDeLog
    {
        public readonly int MD_WARNING = 2;
        public readonly int MD_INFO = 3;
        public readonly int MD_DEBUG = 4;
        public readonly int MD_ERROR = 1;
    }
}
