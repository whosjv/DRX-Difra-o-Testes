﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DRX_ArtAnalysis
{
    public class ConstantesHandel
    {
        public byte AV_MEM_PARSET = 0x04;
        public byte AV_MEM_GENSET = 0x08;

    }
}
