﻿
using System.Diagnostics;
using System.IO.Ports;

using System.Text.RegularExpressions;


namespace DRX_LabMovel.Classes
{
    public class Motor
    {

        #region propriedades

        private string DESTRAVAR_SISTEMA_DE_ALARME_DO_GRBL = "$X";
        private string DEFINIR_MODO_COORDENADAS_ABSOLUTAS_E_FEED_RATE = "G90 F20";
        private double velocidadeAtualDoMotor;     
        private double auxPosicaoDeInicio = 0;

        SerialPort _portaSerial;
        Detector _detector;

        #endregion propriedades


        #region metodos

        public Motor()
        {
            _detector = new Detector();
        }

        public bool ConexaoComMotores(string nomeDaPortaSerial)
        {
            try
            {
                if (_portaSerial != null)
                {
                    if (_portaSerial.IsOpen)
                        _portaSerial.Close();
                }

                var extracaoDoNomeDaPorta = nomeDaPortaSerial.Substring(nomeDaPortaSerial.LastIndexOf("COM"));

                _portaSerial = new SerialPort(extracaoDoNomeDaPorta.Substring(0, extracaoDoNomeDaPorta.Length - 1), 115200);

                _portaSerial.Open();

                _portaSerial.Write("\r\n\r\n");

                Thread.Sleep(1000);

                _portaSerial.DiscardInBuffer();

                Thread.Sleep(1000);

                _portaSerial.WriteLine(DESTRAVAR_SISTEMA_DE_ALARME_DO_GRBL);

                _portaSerial.WriteLine(DEFINIR_MODO_COORDENADAS_ABSOLUTAS_E_FEED_RATE);

                _portaSerial.WriteLine("G1 X0");

                return true;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }


        }

        private void AguardaVareficacaoDaVelocidadeDoMotor()
        {
            VerificaVelecidadeDoMotor();
            Thread.Sleep(100);
            VerificaVelecidadeDoMotor();
            Thread.Sleep(100);

            while (velocidadeAtualDoMotor > 0)
            {
                VerificaVelecidadeDoMotor();
                Thread.Sleep(100);
            }
        }

        private void VerificaVelecidadeDoMotor()
        {
            _portaSerial.WriteLine("??");
            Thread.Sleep(100);

            string resposta = _portaSerial.ReadLine();
            _portaSerial.DiscardInBuffer();

            if (resposta.LastIndexOf('S') != -1)
            {
                if (resposta.Contains("S:"))
                {
                    string padrao = "S:?(\\d*[,.]?\\d*)";
                    Match velocidade = Regex.Match(resposta, padrao);
                    double.TryParse(velocidade.Groups[1].ToString().Replace(",", "."), out velocidadeAtualDoMotor);
                }
            }
        }

        public async Task<bool> MoverParaPosicaoInicial(double posicaoDeInicio)
        {
            auxPosicaoDeInicio = posicaoDeInicio;

            string posicaoDeInicioComoString = Convert.ToString(posicaoDeInicio).Replace(',', '.');
            _portaSerial.WriteLine($"G1 X{posicaoDeInicioComoString}");

            Thread.Sleep(1000);

            decimal valorDeX = await RecuperarCoordenadaDeX();
            if (valorDeX > 0 || valorDeX == 0) return true;
            else return false;

        }

        public Task<decimal> RecuperarCoordenadaDeX()
        {
            if (_portaSerial.BytesToWrite > 0)
            {
                Debug.WriteLine("[MOTOR]: Serial communication is busy. Skipping...");
                return Task.FromResult<decimal>(0); // ou outro valor de erro, dependendo do caso
            }
            _portaSerial.DiscardInBuffer();
            _portaSerial.WriteLine("??");
            Thread.Sleep(10);
            string response = _portaSerial.ReadLine();
            _portaSerial.DiscardInBuffer();

            if (response.StartsWith("<"))
            {
                string[] values = response.Split('|')[1].Split(':')[1].Split(',');
                return Task.FromResult(Convert.ToDecimal(values[0])); // retornar o valor de X
            }
            else
            {
                //Caso ele não consiga buscar o valor do X, ele vai informar a constante abaixo:
                return Task.FromResult<decimal>(1380649);
            }

        }

        public Task FazerAquisicao(double deslocamento, double passoDouble, int tempoDeExecucao)
        {
            return Task.Run(() =>
            {
                for (double i = auxPosicaoDeInicio; i <= (deslocamento); i += passoDouble)
                {
                    Thread.Sleep((int)(tempoDeExecucao * 1000));
                    _portaSerial.WriteLine($"G1 X{i.ToString().Replace(",", ".")}");
                    AguardaVareficacaoDaVelocidadeDoMotor();
                    _detector.CapturarEspectro(i, auxPosicaoDeInicio);
                }
            });
        }

        public void Inicio()
        {
            _portaSerial.WriteLine("G1 X0 F20");
        }

        public void DefinirHome()
        {
            _portaSerial.WriteLine("G92 X0");
        }

        public void FinalizarComunicacao() 
        { 

           if (_portaSerial != null) _portaSerial.Close();
        }
              
        public void FormFechando()
        {
            if (_portaSerial.IsOpen)
            {
                _portaSerial.WriteLine("G0 X0");
                Thread.Sleep(1000);
                _portaSerial.Close();
                Thread.Sleep(1000);
            }
        }

        #endregion metodos


    }
}
