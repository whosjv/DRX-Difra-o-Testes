﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DRX_ArtAnalysis
{
    public class PrioridadesDoSensor
    {
       
        public readonly int MD_IO_PRI_NORMAL = 0;
        public readonly int MD_IO_PRI_HIGH = 1;
    }
}

