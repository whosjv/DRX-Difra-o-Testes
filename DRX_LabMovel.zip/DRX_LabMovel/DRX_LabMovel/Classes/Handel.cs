﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace DRX_LabMovel.Classes
{
    public class Handel
    {
        [DllImport("C:\\Includes\\handel.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int xiaSetLogLevel(int logLevel);

        [DllImport("C:\\Includes\\handel.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int xiaSetLogOutput(string nomeDoArquivo);

        [DllImport("C:\\Includes\\handel.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int xiaInit(string nomeDoArquivoDeInicializacao);

        [DllImport("C:\\Includes\\handel.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int xiaSetIOPriority(int prioridade);

        [DllImport("C:\\Includes\\handel.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int xiaStartSystem();

        [DllImport("C:\\Includes\\handel.dll", CallingConvention = CallingConvention.Cdecl)]
        public unsafe static extern int xiaGetNumDetectors(uint* numDet);

        [DllImport("C:\\Includes\\handel.dll", CallingConvention = CallingConvention.Cdecl)]
        public unsafe static extern int xiaGetDetectors(string* detectors);

        [DllImport("C:\\Includes\\handel.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int xiaStartRun(int detChan, ushort resume);

        [DllImport("C:\\Includes\\handel.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int xiaStopRun(int detChan);

        [DllImport("C:\\Includes\\handel.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int xiaGetDetectors_VB(int nModuleIndex, StringBuilder name);

        [DllImport("C:\\Includes\\handel.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int xiaGetRunData(int detChan, string name, ref ushort value);

        [DllImport("C:\\Includes\\handel.dll", CallingConvention = CallingConvention.Cdecl)]
        public unsafe static extern int xiaGetRunData(int detChan, string name, uint[] value);

        [DllImport("C:\\Includes\\handel.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int xiaSaveSystem(string name, string iniFile);

        [DllImport("C:\\Includes\\handel.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int xiaSetAcquisitionValues(int detChan, string name, ref double value);

        //[DllImport(@"C:\Includes\handel.dll", CallingConvention = CallingConvention.Cdecl)]
        [DllImport("C:\\Includes\\handel.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int xiaBoardOperation(int detChan, string name, ref char value);

        [DllImport("C:\\Includes\\handel.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern int xiaGetDetectorItem(string alias, string name, StringBuilder value);
    }
}
