﻿using DRX_LabMovel.Classes;
using Microsoft.Win32;
using System.Text.RegularExpressions;


namespace DRX_LabMovel
{
    public partial class FormularioDRX : Form
    {
        private List<string> MCPDispostivos;
        public static string caminhoDoArquivoDoProjeto = string.Empty;
        private bool validaConexaoDetector = true;
        private int auxConexaoDetector = 0;

        private bool motorConectado = true;
        public static int tempoDeExecucao = 0;
        private Motor _motor;
        Detector _detector;

        public FormularioDRX()
        {
            MCPDispostivos = new();
            _detector = new Detector();

            InitializeComponent();
            HabilitarControles(true);

            homeToolStripMenuItem.Enabled = true;

            tipLegendas.AutoPopDelay = 4000;
            tipLegendas.InitialDelay = 100;
            tipLegendas.ReshowDelay = 200;

            tipLegendas.SetToolTip(lblPasso, "Passo");
            tipLegendas.SetToolTip(lblAnguloFinal, "Ângulo final");
            tipLegendas.SetToolTip(lblAnguloInicial, "Ângulo inicial");

        }

        private void HabilitarControles(bool estado)
        {
            btnTuboPositivo.Enabled = estado;
            btnDetectorPositivo.Enabled = estado;
            btnTuboNegativo.Enabled = estado;
            btnDetectorNegativo.Enabled = estado;
            tsddbFerramentas.Enabled = estado;
            btnDetectorTuboPositivo.Enabled = estado;
            btnDetectorTuboNegativo.Enabled = estado;

            if (estado) HabilitarDetector();



        }

        private void HabilitarDetector()
        {
            if (_detector.InicializaDetector())
            {
                tsmiDetector.DropDownItems.Add("Detector AXAS -M").Click += new EventHandler(tsmiDetectorRaiosX_DropDownItemsClicked); ;
            }
        }

        private void tsmiDetectorRaiosX_DropDownItemsClicked(object sender, EventArgs e)
        {
            // Converte o parâmetro "sender" para o tipo ToolStripMenuItem
            ToolStripMenuItem? itemDoToolStrip = sender as ToolStripMenuItem;

            // Se o item clicado já estiver marcado, desmarque-o e retorne
            if (itemDoToolStrip.Checked)
            {
                itemDoToolStrip.Checked = false;
                return;
            }

            // Desmarca todos os itens do menu "tsmiMCP" (provavelmente deveria ser "arduinoToolStripMenuItem.DropDownItems")
            foreach (ToolStripMenuItem item in tsmiDetector.DropDownItems)
                item.Checked = false;
            itemDoToolStrip.Checked = true;

            if (!tsmiDetector.Checked)
            {

                if (auxConexaoDetector == 0)
                {
                    _detector.InicializaParametros();
                    validaConexaoDetector = true;

                }
                auxConexaoDetector = 1;


            }
        }

        private void FormularioDRX_Load(object sender, EventArgs e)
        {
            AtualizarListaDeDispositivosConectados();
            this.MinimumSize = new Size(pnlControles.Width, this.Height);

        }

        private static List<string> RecuperarNovoSerialDoDispositivo(List<string> oldDevices)
        {
            List<string> devices = new();
            RegistryKey regSerial = Registry.LocalMachine.OpenSubKey(@"HARDWARE\DEVICEMAP\SERIALCOMM");

            if (regSerial != null)
            {
                try
                {
                    foreach (string key in regSerial.GetValueNames())
                        devices.Add(key.Split(@"\").Last() + $" ({regSerial.GetValue(key)})");
                }
                catch
                {
                    throw new Exception("Falha ao detectar novos dispositivos seriais.");
                }
            }

            return devices.Except(oldDevices).ToList();
        }

        private void AtualizarListaDeDispositivosConectados()
        {
            List<string> newDevices = RecuperarNovoSerialDoDispositivo(MCPDispostivos);
            MCPDispostivos.AddRange(newDevices);

            if (MCPDispostivos.Count == 0)
            {
                tsmiMCP.DropDownItems.Clear();
                tsmiMCP.DropDownItems.Add("Nenhum dispositivo encontrado").Enabled = false;
            }

            foreach (string device in newDevices)
            {
                tsmiMCP.DropDownItems.Add(device).Click += new EventHandler(tsmiMCP_DropDownItemsClicked);
            }
        }

        private void tsmiMCP_DropDownItemsClicked(object sender, EventArgs e)
        {
            // Converte o parâmetro "sender" para o tipo ToolStripMenuItem
            ToolStripMenuItem? itemDoToolStrip = sender as ToolStripMenuItem;

            // Se o item clicado já estiver marcado, desmarque-o e retorne
            if (itemDoToolStrip.Checked)
            {
                itemDoToolStrip.Checked = false;
                return;
            }

            // Desmarca todos os itens do menu "tsmiMCP" (provavelmente deveria ser "arduinoToolStripMenuItem.DropDownItems")
            foreach (ToolStripMenuItem item in tsmiMCP.DropDownItems)
                item.Checked = false;


            // Padrão de expressão regular para extrair o nome da porta dentro dos parênteses
            string padrao = @"^.*[(](\w*)[)]$";

            // Aplica a expressão regular ao texto do item selecionado para extrair o nome da porta
            Match nomeDaPorta = Regex.Match(itemDoToolStrip.Text, padrao);

            if (nomeDaPorta.Success)
            {
                Task.Run(() =>
                {
                    try
                    {

                        _motor = new Motor();
                        _motor.FinalizarComunicacao();
                        motorConectado = _motor.ConexaoComMotores(nomeDaPorta.ToString());

                        // Marca o item clicado como selecionado
                        if (motorConectado)
                        {
                            Invoke(() =>
                            {
                                itemDoToolStrip.Checked = true;
                                btnIniciar.Enabled = true;
                                homeToolStripMenuItem.Enabled = true;
                            });
                        }
                    }
                    catch (Exception ex)
                    {
                    }


                });
            }
        }

        private void tsmiMCP_DropDownOpening(object sender, EventArgs e)
        {
            AtualizarListaDeDispositivosConectados();
        }

        private void tsmiDesconectarDispositivos_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Tem certeza que deseja finalizar todas as conexões?",
                "Conexões", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
        }

        private async void BtnIniciar_Click(object sender, EventArgs e)
        {
            double.TryParse(txtAnguloInicial.Text, out double anguloInicial);
            double.TryParse(txtAnguloFinal.Text, out double anguloFinal);
            double.TryParse(txtPasso.Text, out double passo);
            int.TryParse(txtTempo.Text, out tempoDeExecucao);


            if (anguloInicial == 0 && anguloFinal == 0 && passo == 0 && tempoDeExecucao == 0) MessageBox.Show("É necessário informar os parâmetros.",
                    "Parâmetros da aquisição", MessageBoxButtons.OK, MessageBoxIcon.Error);

            else if (anguloInicial < 16)
                MessageBox.Show("Ângulo inicial não pode ser menor que 16°",
                    "Ângulo inicial", MessageBoxButtons.OK, MessageBoxIcon.Error);

            else if (anguloFinal > 71 || anguloFinal == 0) MessageBox.Show("Ângulo final não pode ser maior que 71 ou ser igual a 0°",
                    "Ângulo inicial", MessageBoxButtons.OK, MessageBoxIcon.Error);

            else if (anguloFinal < anguloInicial)
                MessageBox.Show("Ângulo final não pode ser menor que ângulo inicial.",
                    "Ângulo menor", MessageBoxButtons.OK, MessageBoxIcon.Error);

            else if (tempoDeExecucao == 0) MessageBox.Show("O tempo de aquisição não pode ser 0.",
                                                    "Tempo de aquisição", MessageBoxButtons.OK, MessageBoxIcon.Error);


            else
            {
                if ((anguloFinal) <= 71 && tempoDeExecucao > 0 && validaConexaoDetector == true)
                {
                    HabilitarControles(true);
                    double posicaoDeInicio = (((anguloInicial - 16) * 0.150) / 0.5);
                    double deslocamento = (((anguloFinal - anguloInicial) * 0.150) / 0.5);
                    double passoDouble = ((passo * 0.150) / 0.5); //passo * 0.12
                    var validaPosicaoInicial = _motor.MoverParaPosicaoInicial(posicaoDeInicio);
                    if (validaPosicaoInicial.IsCompleted)
                    {
                        await _motor.FazerAquisicao(deslocamento, passoDouble, tempoDeExecucao);
                        MessageBox.Show("Aquisição Finalizada.", "Aquisição", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        HabilitarControles(true);

                    }
                }
                else if ((anguloFinal) <= 71 && tempoDeExecucao > 0 && validaConexaoDetector == true)
                    MessageBox.Show("Verifique se o detector foi selecionado", "Detector de Raios X", MessageBoxButtons.OK, MessageBoxIcon.Error);


            }
        }

        private void tratamentoDeSpectroDeXRFToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormularioSpectraXRF formularioSpectraXRF = new FormularioSpectraXRF();
            formularioSpectraXRF.Show();
        }

        private void criarProjetoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog abrirPasta = new FolderBrowserDialog();
            abrirPasta.ShowNewFolderButton = true;


            if (abrirPasta.ShowDialog() == DialogResult.OK)
            {
                caminhoDoArquivoDoProjeto = abrirPasta.SelectedPath;
                HabilitarControles(true);
            }

        }

        private void moverseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _motor.Inicio();
        }

        private void definirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _motor.DefinirHome();
        }

        private void FormularioDRX_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_motor != null) _motor.FormFechando();
        }

        private void tsddbFerramentas_Click(object sender, EventArgs e)
        {

        }

        private void txtAnguloInicial_KeyDown(object sender, KeyEventArgs e) // enter para proximo textbox
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                txtAnguloFinal.Focus();
            }
        }

        private void txtAnguloFinal_KeyDown(object sender, KeyEventArgs e) // enter para proximo textbox
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                txtPasso.Focus();
            }
        }

        private void txtPasso_KeyDown(object sender, KeyEventArgs e) // enter para proximo textbox
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                txtTempo.Focus();
            }
        }

        private void txtTempo_KeyDown(object sender, KeyEventArgs e) // enter para proximo combo box
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                cmbNumeroDeCanais.Focus();
            }
        }

        private void cmbNumeroDeCanais_KeyDown(object sender, KeyEventArgs e) // enter para proximo combo box
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                btnIniciar.PerformClick();
            }
        }
    }
}